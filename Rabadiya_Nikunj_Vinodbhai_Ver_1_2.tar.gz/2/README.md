requirement: 
        - python 

Assumption:
        - shard data directly geeting in input.txt 
dependency: 
        - re

How to change input:- edit "input.txt" to add new input or chnage in main.py change the path of file

result:
        - print on tty and store in same directory output.txt